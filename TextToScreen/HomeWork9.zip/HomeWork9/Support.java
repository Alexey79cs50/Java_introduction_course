package com.company.HomeWork9;

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

final public class Support extends User {
    private String accessGroup;

    public Support() {
    }

    public Support(String name, String surname, String mail, String password, String gender, String country, String accessGroup) {
        super(name, surname, mail, password, gender, country);
        this.accessGroup = accessGroup;
    }

    public boolean check(String input) throws IOException {
        FileReader file = new FileReader(Main.WORK_FILE);
        Scanner scanner = new Scanner(file);
        boolean result =  scanner.nextLine().equals(input);
        file.close();
        scanner.close();
        return result;
    }

    public String getAccessGroup() {
        return accessGroup;
    }

    public void setAccessGroup(String accessGroup) {
        this.accessGroup = accessGroup;
    }
}
